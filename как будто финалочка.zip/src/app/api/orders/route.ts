import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { getAllOrders, getOrdersForCourier, createOrder, validatePromoCode } from "@/lib/data-service";
import { logError } from "@/lib/logger";

const CUSTOMER_PHONE_COOKIE = "slay_customer_phone";

/**
 * GET /api/orders
 * - ADMIN сессия → все заказы (для /admin/orders)
 * - COURIER сессия → только назначенные ему заказы (для /courier)
 * Доступ клиента к своим заказам — через /api/me/orders (по телефону), не здесь.
 */
export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ error: "Требуется авторизация" }, { status: 401 });

    if (user.role === "ADMIN") {
      const orders = await getAllOrders();
      return NextResponse.json({ orders });
    }

    if (user.role === "COURIER") {
      const orders = await getOrdersForCourier(user.id);
      return NextResponse.json({ orders });
    }

    return NextResponse.json({ error: "Недостаточно прав" }, { status: 403 });
  } catch (error) {
    await logError("api/orders GET", error);
    return NextResponse.json({ error: "Не удалось загрузить заказы" }, { status: 500 });
  }
}

/**
 * POST /api/orders — публичный эндпоинт оформления заказа (checkout).
 * Промокод (если указан) валидируется и пересчитывается на сервере —
 * клиентский promoDiscount не принимается на веру, чтобы нельзя было
 * подделать скидку в запросе.
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { lines, total, subtotal, deliveryFee, discount, address, customerName, customerPhone, comment, paymentMethod, promoCode } =
      body;

    if (!Array.isArray(lines) || lines.length === 0) {
      return NextResponse.json({ error: "Корзина пуста" }, { status: 400 });
    }
    if (!address || !customerName || !customerPhone) {
      return NextResponse.json({ error: "Заполните имя, телефон и адрес" }, { status: 400 });
    }

    let promoDiscount = 0;
    let appliedPromoCode: string | null = null;

    if (promoCode) {
      const existingCustomer = await prisma.user.findUnique({ where: { phone: customerPhone } });
      const result = await validatePromoCode(promoCode, existingCustomer?.id);
      if (!result.ok) {
        return NextResponse.json({ error: result.error }, { status: 400 });
      }
      promoDiscount = Math.round((Number(subtotal) * result.discountPercent) / 100);
      appliedPromoCode = promoCode.trim().toUpperCase();
    }

    const recomputedTotal = Math.max(Number(subtotal) - promoDiscount, 0) + Number(deliveryFee);

    const order = await createOrder({
      lines,
      total: recomputedTotal,
      subtotal,
      deliveryFee,
      discount: discount ?? 0,
      promoCode: appliedPromoCode,
      promoDiscount,
      address,
      customerName,
      customerPhone,
      comment,
      paymentMethod: paymentMethod ?? "card"
    });

    const response = NextResponse.json({ order }, { status: 201 });
    response.cookies.set(CUSTOMER_PHONE_COOKIE, customerPhone, {
      httpOnly: true,
      sameSite: "lax",
      path: "/",
      maxAge: 60 * 60 * 24 * 365
    });
    return response;
  } catch (error) {
    await logError("api/orders POST", error);
    return NextResponse.json({ error: "Не удалось оформить заказ" }, { status: 500 });
  }
}
