import type { Metadata, Viewport } from "next";
import { Inter, Manrope } from "next/font/google";
import "./globals.css";
import ServiceWorkerRegister from "@/components/service-worker-register";
import ToastContainer from "@/components/toast-container";

const manrope = Manrope({
  subsets: ["latin", "cyrillic"],
  variable: "--font-display",
  weight: ["500", "600", "700", "800"]
});

const inter = Inter({
  subsets: ["latin", "cyrillic"],
  variable: "--font-body",
  weight: ["400", "500", "600", "700"]
});

export const metadata: Metadata = {
  title: {
    default: "СЛЭЙ доставка — продукты за 15 минут",
    template: "%s — СЛЭЙ доставка"
  },
  description:
    "СЛЭЙ доставка — сервис доставки продуктов из дарксторов рядом с вами. Свежие овощи, фрукты, мясо и всё для дома за 15 минут.",
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "СЛЭЙ"
  },
  openGraph: {
    title: "СЛЭЙ доставка — продукты за 15 минут",
    description: "Свежие продукты с доставкой на дом. Быстро, удобно, выгодно.",
    type: "website",
    locale: "ru_RU",
    siteName: "СЛЭЙ доставка"
  },
  icons: {
    icon: "/icons/icon-192.png",
    apple: "/icons/icon-192.png"
  }
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  viewportFit: "cover",
  themeColor: "#ffffff"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ru" className={`${manrope.variable} ${inter.variable}`}>
      <body className="font-body antialiased min-h-screen bg-white text-ink">
        <ServiceWorkerRegister />
        <ToastContainer />
        {children}
      </body>
    </html>
  );
}
