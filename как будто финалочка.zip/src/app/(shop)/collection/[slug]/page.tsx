import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getCollectionBySlug } from "@/lib/catalog";
import ProductGrid from "@/components/product-grid";
import BackButton from "@/components/back-button";

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const collection = await getCollectionBySlug(params.slug);
  return { title: collection ? collection.title : "Подборка" };
}

export const revalidate = 0;

export default async function CollectionPage({ params }: { params: { slug: string } }) {
  const collection = await getCollectionBySlug(params.slug);
  if (!collection || collection.active === false) notFound();

  return (
    <div className="mx-auto max-w-6xl px-4 py-4 md:px-6">
      <BackButton className="mb-3" fallbackHref="/" />
      <h1 className="mb-1 font-display text-xl font-bold">{collection.title}</h1>
      <p className="mb-4 text-xs text-smoke-400">{collection.products.length} товаров</p>

      <ProductGrid products={collection.products} />
    </div>
  );
}
