import type { Metadata } from "next";
import Link from "next/link";
import { Suspense } from "react";
import { ArrowRight } from "lucide-react";
import { filterProducts, getBrandsForCategory, getCategories, type SortOption } from "@/lib/catalog";
import ProductGrid from "@/components/product-grid";
import FilterBar from "@/components/filter-bar";
import BackButton from "@/components/back-button";
import CategoryCard from "@/components/category-card";
import SearchBar from "@/components/search-bar";

export const metadata: Metadata = {
  title: "Каталог"
};

export const revalidate = 0;

export default async function CatalogPage({
  searchParams
}: {
  searchParams: { sort?: string; filter?: string; brand?: string; minPrice?: string; maxPrice?: string };
}) {
  // Каталог — это в первую очередь выбор категории. Список товаров без
  // категории показываем только если человек пришёл по конкретной ссылке
  // с главной (сортировка/фильтр/бренд/цена) — например "Новинки" или
  // "Скидки". В остальных случаях — сначала категории, потом товары.
  const hasFilters = Boolean(
    searchParams.sort || searchParams.filter || searchParams.brand || searchParams.minPrice || searchParams.maxPrice
  );

  const categories = await getCategories({ onlyActive: true });

  if (!hasFilters) {
    return (
      <div className="mx-auto max-w-6xl px-4 py-4 md:px-6">
        <BackButton className="mb-3" fallbackHref="/" />
        <h1 className="mb-1 font-display text-xl font-bold">Каталог</h1>
        <p className="mb-4 text-sm text-smoke-500">Выберите категорию, чтобы посмотреть товары</p>

        <div className="mb-5">
          <SearchBar />
        </div>

        <div className="grid grid-cols-3 gap-2.5 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6">
          {categories.map((c) => (
            <CategoryCard key={c.slug} category={c} />
          ))}
        </div>

        <Link
          href="/catalog?sort=relevance"
          className="mt-6 flex items-center justify-center gap-1.5 rounded-full border border-smoke-200 py-3 text-sm font-semibold text-smoke-600 transition-colors hover:bg-smoke-50"
        >
          Смотреть все товары
          <ArrowRight size={15} />
        </Link>
      </div>
    );
  }

  const sort = (searchParams.sort as SortOption) || "relevance";
  const [products, brands] = await Promise.all([
    filterProducts({
      sort,
      onlyDiscount: searchParams.filter === "discount",
      onlyNew: searchParams.filter === "new",
      brand: searchParams.brand,
      minPrice: searchParams.minPrice ? Number(searchParams.minPrice) : undefined,
      maxPrice: searchParams.maxPrice ? Number(searchParams.maxPrice) : undefined
    }),
    getBrandsForCategory()
  ]);

  return (
    <div className="mx-auto max-w-6xl px-4 py-4 md:px-6">
      <BackButton className="mb-3" fallbackHref="/catalog" />
      <h1 className="mb-4 font-display text-xl font-bold">Каталог</h1>

      <div className="mb-5">
        <SearchBar />
      </div>

      <div className="no-scrollbar mb-5 flex gap-2 overflow-x-auto">
        {categories.map((c) => (
          <Link
            key={c.slug}
            href={`/category/${c.slug}`}
            className="flex shrink-0 items-center gap-1.5 rounded-full bg-smoke-100 px-3.5 py-2 text-xs font-medium text-ink"
          >
            <span>{c.emoji}</span>
            {c.name}
          </Link>
        ))}
      </div>

      <Suspense fallback={null}>
        <FilterBar brands={brands} />
      </Suspense>

      <ProductGrid products={products} />
    </div>
  );
}
