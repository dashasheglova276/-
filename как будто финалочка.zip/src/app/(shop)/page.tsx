import HeroBanner from "@/components/hero-banner";
import Section from "@/components/section";
import ProductRail from "@/components/product-rail";
import CategoryCard from "@/components/category-card";
import CollectionCard from "@/components/collection-card";
import RecipeCard from "@/components/recipe-card";
import RepeatOrder from "@/components/repeat-order";
import PromoBanner from "@/components/promo-banner";
import SearchBar from "@/components/search-bar";
import {
  getPopularProducts,
  getNewProducts,
  getDiscountedProducts,
  getRecommendedProducts,
  getCategories,
  getRecipes,
  getCollections
} from "@/lib/catalog";

export const revalidate = 0;

export default async function HomePage() {
  const [popular, fresh, discounted, recommended, categories, recipes, collections] = await Promise.all([
    getPopularProducts(10),
    getNewProducts(10),
    getDiscountedProducts(10),
    getRecommendedProducts(10),
    getCategories({ onlyActive: true }),
    getRecipes(),
    getCollections({ onlyActive: true })
  ]);

  return (
    <div className="mx-auto max-w-6xl px-4 md:px-6">
      {/* Крупный поиск — часть Главной, отдельной вкладки в BottomNav нет по ТЗ */}
      <div className="pt-4">
        <SearchBar />
      </div>

      {/* Hero — классический слайдер из редизайн-версии: 3 промо-слайда
          (скидки, регистрация −15%, доставка), автопрокрутка каждые 5с,
          точки-индикаторы. Один из слайдов уже покрывает промо регистрации,
          поэтому отдельный статичный баннер под хиро не нужен. */}
      <HeroBanner />

      {/* Каталог — компактные круглые иконки категорий, как в редизайн-версии */}
      <Section title="Каталог" subtitle="Выберите категорию" href="/catalog">
        <div className="grid grid-cols-3 gap-2 sm:grid-cols-6 md:grid-cols-8">
          {categories.slice(0, 9).map((c) => (
            <CategoryCard key={c.slug} category={c} />
          ))}
        </div>
      </Section>

      {/* Популярные товары — сразу после каталога, по кратчайшему пути к покупке */}
      <Section title="Популярные товары" subtitle="Чаще всего берут с СЛЭЙ" href="/catalog?sort=rating">
        <ProductRail products={popular} />
      </Section>

      {/* Светящийся чёрно-градиентный promo-баннер посреди сайта — фирменный
          элемент дизайна, всегда на месте в середине ленты главной страницы */}
      <div className="my-2">
        <PromoBanner />
      </div>

      {/* Подборки — горизонтальный слайдер, листается свайпом. Пока админ не
          создал ни одной подборки в БД, секция не рендерится вовсе. */}
      {collections.length > 0 && (
        <Section title="Подборки" subtitle="Собрали всё нужное под одну задачу">
          <div className="no-scrollbar -mx-4 flex snap-x snap-mandatory gap-2.5 overflow-x-auto px-4 pb-1 sm:mx-0 sm:px-0">
            {collections.map((c) => (
              <CollectionCard key={c.slug} collection={c} />
            ))}
          </div>
        </Section>
      )}

      {/* Рецепты — карточки с крупным фото, открытие ведёт на страницу рецепта,
          где все ингредиенты можно добавить в корзину одной кнопкой */}
      <Section title="Что приготовить сегодня?" subtitle="Ингредиенты — в корзину одним нажатием" href="/recipes">
        <div className="no-scrollbar -mx-4 flex snap-x gap-3 overflow-x-auto px-4 pb-1 sm:mx-0 sm:grid sm:grid-cols-4 sm:overflow-visible sm:px-0">
          {recipes.slice(0, 4).map((r) => (
            <div key={r.slug} className="w-40 shrink-0 snap-start sm:w-auto">
              <RecipeCard recipe={r} />
            </div>
          ))}
        </div>
      </Section>

      <Section title="Новинки" subtitle="Только появились у нас" href="/catalog?filter=new">
        <ProductRail products={fresh} />
      </Section>

      {/* Второстепенные блоки — ниже основного пути пользователя */}
      <RepeatOrder />

      <Section title="Скидки" subtitle="Пока цена ниже обычной" href="/catalog?filter=discount">
        <ProductRail products={discounted} />
      </Section>

      <Section title="Рекомендуем" subtitle="Подобрали специально для вас">
        <ProductRail products={recommended} />
      </Section>
    </div>
  );
}
