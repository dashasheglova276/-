"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  User,
  Package,
  Gift,
  Ticket,
  Settings,
  ChevronRight,
  ChevronLeft,
  RotateCcw,
  Bell,
  MapPin,
  LogOut,
  UserPlus,
  LogIn,
  Plus,
  Trash2,
  Star,
  Pencil,
  Check,
  Heart
} from "lucide-react";
import { useCartStore } from "@/context/cart-store";
import { useToastStore } from "@/context/toast-store";
import type { AdminOrder } from "@/types";
import { CANCELLABLE_STATUSES } from "@/types";
import StatusBadge from "@/components/status-badge";
import BackButton from "@/components/back-button";
import { formatPrice, cn } from "@/lib/utils";

type Tab = "orders" | "bonuses" | "promocodes" | "settings";
type SettingsView = "menu" | "personal" | "addresses" | "notifications";

interface CurrentUser {
  id: string;
  name: string;
  phone: string;
  role: string;
}

interface AddressDto {
  id: string;
  label: string;
  address: string;
  entrance: string | null;
  floor: string | null;
  apartment: string | null;
  comment: string | null;
  isDefault: boolean;
}

const tabs: { id: Tab; label: string; icon: typeof Package }[] = [
  { id: "orders", label: "Заказы", icon: Package },
  { id: "bonuses", label: "Бонусы", icon: Gift },
  { id: "promocodes", label: "Промокоды", icon: Ticket },
  { id: "settings", label: "Настройки", icon: Settings }
];

export default function ProfilePage() {
  const router = useRouter();
  const [authChecked, setAuthChecked] = useState(false);
  const [user, setUser] = useState<CurrentUser | null>(null);
  const [tab, setTab] = useState<Tab>("orders");
  const [orders, setOrders] = useState<AdminOrder[]>([]);
  const [ordersLoading, setOrdersLoading] = useState(true);
  const addItem = useCartStore((s) => s.addItem);
  const showToast = useToastStore((s) => s.show);

  useEffect(() => {
    fetch("/api/auth/me")
      .then((res) => res.json())
      .then((data) => {
        setUser(data.user ?? null);
        setAuthChecked(true);
      });
  }, []);

  useEffect(() => {
    if (!user) return;
    fetch("/api/me/orders")
      .then((res) => res.json())
      .then((data) => setOrders(data.orders ?? []))
      .finally(() => setOrdersLoading(false));
  }, [user]);

  async function repeat(order: AdminOrder) {
    const res = await fetch(`/api/products?ids=${order.items.map((i) => i.productId).join(",")}`);
    const data = await res.json();
    const products: Record<string, { id: string }> = Object.fromEntries(
      (data.products ?? []).map((p: { id: string }) => [p.id, p])
    );
    order.items.forEach((item) => {
      const product = products[item.productId];
      if (product) addItem(product as Parameters<typeof addItem>[0], item.quantity);
    });
  }

  async function cancelOrder(orderId: string) {
    if (!confirm("Отменить заказ? Действие нельзя будет вернуть.")) return;
    const res = await fetch(`/api/me/orders/${orderId}/cancel`, { method: "POST" });
    const data = await res.json();
    if (!res.ok) {
      showToast(data.error ?? "Не удалось отменить заказ", "error");
      return;
    }
    setOrders((prev) => prev.map((o) => (o.id === orderId ? { ...o, status: "cancelled" } : o)));
    showToast("Заказ отменён", "success");
  }

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    setUser(null);
    router.push("/");
    router.refresh();
  }

  // Пока не знаем, авторизован ли пользователь — ничего не мигаем
  if (!authChecked) {
    return <div className="py-24 text-center text-sm text-smoke-400">Загрузка…</div>;
  }

  // Гость — вместо пустого профиля показываем экран с призывом войти/зарегистрироваться
  if (!user) {
    return (
      <div className="mx-auto flex min-h-[70vh] max-w-sm flex-col items-center justify-center px-6 text-center">
        <BackButton className="absolute left-4 top-4" fallbackHref="/" />
        <div className="flex h-16 w-16 items-center justify-center rounded-full bg-smoke-100">
          <User size={28} className="text-smoke-400" />
        </div>
        <h1 className="mt-4 font-display text-xl font-bold text-ink">Вы не авторизованы</h1>
        <p className="mt-1.5 text-sm text-smoke-500">
          Войдите или создайте аккаунт, чтобы увидеть заказы, бонусы и адреса доставки.
        </p>
        <div className="mt-6 flex w-full flex-col gap-2">
          <Link
            href="/register?from=/profile"
            className="flex items-center justify-center gap-2 rounded-full bg-lime-500 py-3 text-sm font-bold text-ink shadow-glowLime"
          >
            <UserPlus size={16} />
            Зарегистрироваться
          </Link>
          <Link
            href="/account/login?from=/profile"
            className="flex items-center justify-center gap-2 rounded-full bg-ink py-3 text-sm font-bold text-white"
          >
            <LogIn size={16} />
            Войти
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-4 md:px-6">
      <BackButton className="mb-3" fallbackHref="/" />
      <div className="mb-5 flex items-center gap-3">
        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-smoke-100">
          <User size={24} className="text-smoke-500" />
        </div>
        <div>
          <h1 className="font-display text-lg font-bold">{user.name}</h1>
          <p className="text-xs text-smoke-400">
            {user.phone} · {orders.length} заказов
          </p>
        </div>
      </div>

      <div className="no-scrollbar mb-5 flex gap-2 overflow-x-auto">
        {tabs.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            className={cn(
              "flex shrink-0 items-center gap-1.5 rounded-full border px-3.5 py-2 text-xs font-semibold transition-colors",
              tab === id ? "border-ink bg-ink text-white" : "border-smoke-200 text-smoke-600"
            )}
          >
            <Icon size={14} />
            {label}
          </button>
        ))}
      </div>

      {tab === "orders" && (
        <div className="flex flex-col gap-3">
          {ordersLoading ? (
            <p className="py-8 text-center text-sm text-smoke-400">Загрузка…</p>
          ) : orders.length === 0 ? (
            <EmptyBlock text="У вас пока нет заказов" />
          ) : (
            orders.map((order) => (
              <Link
                key={order.id}
                href={`/orders/${order.id}`}
                className="block rounded-xl2 border border-smoke-100 p-4 transition-colors active:bg-smoke-50"
              >
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold">{order.id}</span>
                  <StatusBadge status={order.status} />
                </div>
                <p className="mt-1 text-xs text-smoke-400">
                  {new Date(order.createdAt).toLocaleString("ru-RU", {
                    day: "numeric",
                    month: "long",
                    hour: "2-digit",
                    minute: "2-digit"
                  })}
                </p>
                <p className="mt-2 line-clamp-1 text-sm text-smoke-600">
                  {order.items.map((i) => i.name).join(", ")}
                </p>
                <div className="mt-3 flex items-center justify-between gap-2">
                  <span className="font-display text-base font-bold">{formatPrice(order.total)}</span>
                  <div className="flex items-center gap-2">
                    {CANCELLABLE_STATUSES.includes(order.status) && (
                      <button
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          cancelOrder(order.id);
                        }}
                        className="flex items-center gap-1.5 rounded-full border border-flash-200 px-3.5 py-2 text-xs font-semibold text-flash-600"
                      >
                        Отменить
                      </button>
                    )}
                    <button
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        repeat(order);
                      }}
                      className="flex items-center gap-1.5 rounded-full bg-smoke-100 px-3.5 py-2 text-xs font-semibold"
                    >
                      <RotateCcw size={13} />
                      Повторить
                    </button>
                  </div>
                </div>
              </Link>
            ))
          )}
        </div>
      )}

      {tab === "bonuses" && (
        <div className="flex flex-col gap-4">
          <div className="rounded-xl2 bg-ink p-5 text-white">
            <p className="text-xs text-white/60">Ваш бонусный баланс</p>
            <p className="mt-1 font-display text-3xl font-extrabold text-lime-500">248 ₽</p>
            <p className="mt-2 text-xs text-white/60">1 бонус = 1 ₽. Списывайте до 20% от суммы заказа</p>
          </div>
          <div className="rounded-xl2 border border-smoke-100 p-4 text-sm text-smoke-600">
            Начисляем 3% от каждого заказа бонусами. Они появляются на балансе через сутки после доставки.
          </div>
        </div>
      )}

      {tab === "promocodes" && (
        <div className="flex flex-col gap-3">
          {[
            { code: "SLAY10", desc: "Скидка 10% на любой заказ" },
            { code: "FIRST15", desc: "Скидка 15% на первый заказ" },
            { code: "LIME20", desc: "Скидка 20% при заказе от 2000 ₽" }
          ].map((p) => (
            <div key={p.code} className="flex items-center justify-between rounded-xl2 border border-smoke-100 p-4">
              <div>
                <p className="font-display text-sm font-bold">{p.code}</p>
                <p className="text-xs text-smoke-400">{p.desc}</p>
              </div>
              <Link href="/cart" className="rounded-full bg-lime-500 px-3.5 py-2 text-xs font-bold text-ink">
                Применить
              </Link>
            </div>
          ))}
        </div>
      )}

      {tab === "settings" && <SettingsPanel user={user} onLogout={logout} onUserUpdated={(name) => setUser({ ...user, name })} />}
    </div>
  );
}

function SettingsPanel({
  user,
  onLogout,
  onUserUpdated
}: {
  user: CurrentUser;
  onLogout: () => void;
  onUserUpdated: (name: string) => void;
}) {
  const [view, setView] = useState<SettingsView>("menu");

  if (view === "personal") return <PersonalDataView user={user} onBack={() => setView("menu")} onSaved={onUserUpdated} />;
  if (view === "addresses") return <AddressesView onBack={() => setView("menu")} />;
  if (view === "notifications") return <NotificationsView onBack={() => setView("menu")} />;

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-col divide-y divide-smoke-100 rounded-xl2 border border-smoke-100">
        <Link
          href="/favorites"
          className="flex items-center justify-between p-4 text-left text-sm"
        >
          <span className="flex items-center gap-3">
            <Heart size={17} className="text-smoke-400" />
            Понравившиеся товары
          </span>
          <ChevronRight size={16} className="text-smoke-300" />
        </Link>
        <SettingsRow icon={MapPin} label="Адреса доставки" onClick={() => setView("addresses")} />
        <SettingsRow icon={Bell} label="Уведомления" onClick={() => setView("notifications")} />
        <SettingsRow icon={User} label="Личные данные" onClick={() => setView("personal")} />
        <SettingsRow icon={LogOut} label="Выйти" danger onClick={onLogout} />
      </div>

      {/* Демо-переходы в служебные интерфейсы — доступ к ним разграничен ролями ADMIN/COURIER и защищён middleware. */}
      <div className="rounded-xl2 border border-dashed border-smoke-200 p-4">
        <p className="mb-2 text-xs font-semibold text-smoke-400">Для сотрудников</p>
        <div className="flex flex-wrap gap-2">
          <Link href="/admin" className="rounded-full bg-ink px-3.5 py-2 text-xs font-semibold text-white">
            Админ-панель
          </Link>
          <Link href="/courier" className="rounded-full bg-smoke-100 px-3.5 py-2 text-xs font-semibold text-ink">
            Кабинет курьера
          </Link>
        </div>
      </div>
    </div>
  );
}

function SettingsRow({
  icon: Icon,
  label,
  danger,
  onClick
}: {
  icon: typeof MapPin;
  label: string;
  danger?: boolean;
  onClick: () => void;
}) {
  return (
    <button onClick={onClick} className={cn("flex items-center justify-between p-4 text-left text-sm", danger && "text-flash-600")}>
      <span className="flex items-center gap-3">
        <Icon size={17} className={danger ? "text-flash-500" : "text-smoke-400"} />
        {label}
      </span>
      {!danger && <ChevronRight size={16} className="text-smoke-300" />}
    </button>
  );
}

function SettingsSubHeader({ title, onBack }: { title: string; onBack: () => void }) {
  return (
    <button onClick={onBack} className="mb-4 flex items-center gap-1.5 text-sm font-semibold text-ink">
      <ChevronLeft size={17} />
      {title}
    </button>
  );
}

function PersonalDataView({
  user,
  onBack,
  onSaved
}: {
  user: CurrentUser;
  onBack: () => void;
  onSaved: (name: string) => void;
}) {
  const [name, setName] = useState(user.name);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");

  async function save() {
    setError("");
    if (name.trim().length < 2) {
      setError("Имя должно быть не короче 2 символов");
      return;
    }
    setSaving(true);
    const res = await fetch("/api/me/profile", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: name.trim() })
    });
    setSaving(false);
    if (!res.ok) {
      const data = await res.json();
      setError(data.error ?? "Не удалось сохранить");
      return;
    }
    onSaved(name.trim());
    setSaved(true);
    setTimeout(() => setSaved(false), 1600);
  }

  return (
    <div>
      <SettingsSubHeader title="Личные данные" onBack={onBack} />
      <div className="flex flex-col gap-3">
        <label className="flex flex-col gap-1.5">
          <span className="text-xs font-medium text-smoke-500">Имя</span>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="rounded-xl2 border border-smoke-200 px-4 py-3 text-sm outline-none ring-lime-500/60 focus:ring-2"
          />
        </label>
        <label className="flex flex-col gap-1.5">
          <span className="text-xs font-medium text-smoke-500">Телефон</span>
          <input
            value={user.phone}
            disabled
            className="rounded-xl2 border border-smoke-100 bg-smoke-50 px-4 py-3 text-sm text-smoke-400 outline-none"
          />
          <span className="text-[11px] text-smoke-400">Смена телефона временно недоступна</span>
        </label>
        {error && <p className="text-sm text-flash-600">{error}</p>}
        <button
          onClick={save}
          disabled={saving}
          className="mt-1 flex items-center justify-center gap-2 rounded-full bg-lime-500 py-3 text-sm font-bold text-ink shadow-glowLime disabled:opacity-60"
        >
          {saved ? <Check size={16} /> : null}
          {saving ? "Сохраняем…" : saved ? "Сохранено" : "Сохранить"}
        </button>
      </div>
    </div>
  );
}

function AddressesView({ onBack }: { onBack: () => void }) {
  const [addresses, setAddresses] = useState<AddressDto[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<AddressDto | null>(null);

  function reload() {
    fetch("/api/me/addresses")
      .then((res) => res.json())
      .then((data) => {
        setAddresses(data.addresses ?? []);
        setLoading(false);
      });
  }

  useEffect(reload, []);

  async function remove(id: string) {
    setAddresses((prev) => prev.filter((a) => a.id !== id));
    await fetch(`/api/me/addresses/${id}`, { method: "DELETE" });
  }

  async function makeDefault(id: string) {
    await fetch(`/api/me/addresses/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isDefault: true })
    });
    reload();
  }

  if (showForm || editing) {
    return (
      <AddressForm
        initial={editing ?? undefined}
        onCancel={() => {
          setShowForm(false);
          setEditing(null);
        }}
        onSaved={() => {
          setShowForm(false);
          setEditing(null);
          reload();
        }}
      />
    );
  }

  return (
    <div>
      <SettingsSubHeader title="Адреса доставки" onBack={onBack} />
      {loading ? (
        <p className="py-8 text-center text-sm text-smoke-400">Загрузка…</p>
      ) : (
        <div className="flex flex-col gap-2">
          {addresses.length === 0 && (
            <p className="rounded-xl2 border border-dashed border-smoke-200 p-4 text-center text-sm text-smoke-500">
              Пока нет сохранённых адресов
            </p>
          )}
          {addresses.map((a) => (
            <div key={a.id} className="rounded-xl2 border border-smoke-100 p-3.5">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="flex items-center gap-1.5 text-sm font-semibold text-ink">
                    {a.label}
                    {a.isDefault && <Star size={12} className="fill-lime-500 text-lime-500" />}
                  </p>
                  <p className="mt-0.5 text-xs text-smoke-500">{a.address}</p>
                  {(a.entrance || a.floor || a.apartment) && (
                    <p className="mt-0.5 text-[11px] text-smoke-400">
                      {[a.entrance && `подъезд ${a.entrance}`, a.floor && `этаж ${a.floor}`, a.apartment && `кв. ${a.apartment}`]
                        .filter(Boolean)
                        .join(" · ")}
                    </p>
                  )}
                </div>
                <div className="flex shrink-0 gap-1">
                  <button
                    onClick={() => setEditing(a)}
                    aria-label="Изменить"
                    className="flex h-7 w-7 items-center justify-center rounded-full bg-smoke-100 text-smoke-600"
                  >
                    <Pencil size={12} />
                  </button>
                  <button
                    onClick={() => remove(a.id)}
                    aria-label="Удалить"
                    className="flex h-7 w-7 items-center justify-center rounded-full bg-smoke-100 text-flash-600"
                  >
                    <Trash2 size={12} />
                  </button>
                </div>
              </div>
              {!a.isDefault && (
                <button onClick={() => makeDefault(a.id)} className="mt-2 text-[11px] font-semibold text-lime-700">
                  Сделать основным
                </button>
              )}
            </div>
          ))}
        </div>
      )}
      <button
        onClick={() => setShowForm(true)}
        className="mt-3 flex w-full items-center justify-center gap-1.5 rounded-full border border-dashed border-smoke-300 py-2.5 text-xs font-semibold text-smoke-500 hover:border-lime-500 hover:text-lime-700"
      >
        <Plus size={14} />
        Добавить адрес
      </button>
    </div>
  );
}

function AddressForm({
  initial,
  onCancel,
  onSaved
}: {
  initial?: AddressDto;
  onCancel: () => void;
  onSaved: () => void;
}) {
  const [label, setLabel] = useState(initial?.label ?? "Дом");
  const [address, setAddress] = useState(initial?.address ?? "");
  const [entrance, setEntrance] = useState(initial?.entrance ?? "");
  const [floor, setFloor] = useState(initial?.floor ?? "");
  const [apartment, setApartment] = useState(initial?.apartment ?? "");
  const [comment, setComment] = useState(initial?.comment ?? "");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  async function save() {
    setError("");
    if (!address.trim()) {
      setError("Укажите адрес");
      return;
    }
    setSaving(true);
    const payload = { label, address, entrance, floor, apartment, comment };
    const res = initial
      ? await fetch(`/api/me/addresses/${initial.id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        })
      : await fetch("/api/me/addresses", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        });
    setSaving(false);
    if (!res.ok) {
      const data = await res.json();
      setError(data.error ?? "Не удалось сохранить адрес");
      return;
    }
    onSaved();
  }

  return (
    <div>
      <button onClick={onCancel} className="mb-4 flex items-center gap-1.5 text-sm font-semibold text-ink">
        <ChevronLeft size={17} />
        {initial ? "Изменить адрес" : "Новый адрес"}
      </button>
      <div className="flex flex-col gap-3">
        <label className="flex flex-col gap-1.5">
          <span className="text-xs font-medium text-smoke-500">Название</span>
          <input
            value={label}
            onChange={(e) => setLabel(e.target.value)}
            placeholder="Дом, Работа..."
            className="rounded-xl2 border border-smoke-200 px-4 py-3 text-sm outline-none ring-lime-500/60 focus:ring-2"
          />
        </label>
        <label className="flex flex-col gap-1.5">
          <span className="text-xs font-medium text-smoke-500">Адрес</span>
          <input
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            placeholder="Улица, дом"
            className="rounded-xl2 border border-smoke-200 px-4 py-3 text-sm outline-none ring-lime-500/60 focus:ring-2"
          />
        </label>
        <div className="grid grid-cols-3 gap-2">
          <label className="flex flex-col gap-1.5">
            <span className="text-xs font-medium text-smoke-500">Подъезд</span>
            <input
              value={entrance}
              onChange={(e) => setEntrance(e.target.value)}
              className="rounded-xl2 border border-smoke-200 px-2.5 py-3 text-sm outline-none ring-lime-500/60 focus:ring-2"
            />
          </label>
          <label className="flex flex-col gap-1.5">
            <span className="text-xs font-medium text-smoke-500">Этаж</span>
            <input
              value={floor}
              onChange={(e) => setFloor(e.target.value)}
              className="rounded-xl2 border border-smoke-200 px-2.5 py-3 text-sm outline-none ring-lime-500/60 focus:ring-2"
            />
          </label>
          <label className="flex flex-col gap-1.5">
            <span className="text-xs font-medium text-smoke-500">Кв.</span>
            <input
              value={apartment}
              onChange={(e) => setApartment(e.target.value)}
              className="rounded-xl2 border border-smoke-200 px-2.5 py-3 text-sm outline-none ring-lime-500/60 focus:ring-2"
            />
          </label>
        </div>
        <label className="flex flex-col gap-1.5">
          <span className="text-xs font-medium text-smoke-500">Комментарий курьеру</span>
          <input
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder="Домофон не работает, звонить..."
            className="rounded-xl2 border border-smoke-200 px-4 py-3 text-sm outline-none ring-lime-500/60 focus:ring-2"
          />
        </label>
        {error && <p className="text-sm text-flash-600">{error}</p>}
        <button
          onClick={save}
          disabled={saving}
          className="mt-1 rounded-full bg-lime-500 py-3 text-sm font-bold text-ink shadow-glowLime disabled:opacity-60"
        >
          {saving ? "Сохраняем…" : "Сохранить адрес"}
        </button>
      </div>
    </div>
  );
}

function NotificationsView({ onBack }: { onBack: () => void }) {
  const [orderUpdates, setOrderUpdates] = useState(true);
  const [promos, setPromos] = useState(true);
  const [news, setNews] = useState(false);

  useEffect(() => {
    const saved = typeof window !== "undefined" ? localStorage.getItem("slay_notif_prefs") : null;
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setOrderUpdates(parsed.orderUpdates ?? true);
        setPromos(parsed.promos ?? true);
        setNews(parsed.news ?? false);
      } catch {}
    }
  }, []);

  function toggle(key: "orderUpdates" | "promos" | "news", value: boolean) {
    const next = { orderUpdates, promos, news, [key]: value };
    setOrderUpdates(next.orderUpdates);
    setPromos(next.promos);
    setNews(next.news);
    localStorage.setItem("slay_notif_prefs", JSON.stringify(next));
  }

  return (
    <div>
      <SettingsSubHeader title="Уведомления" onBack={onBack} />
      <div className="flex flex-col divide-y divide-smoke-100 rounded-xl2 border border-smoke-100">
        <NotifRow label="Статус заказа" desc="Когда курьер в пути и заказ доставлен" checked={orderUpdates} onChange={(v) => toggle("orderUpdates", v)} />
        <NotifRow label="Акции и промокоды" desc="Персональные скидки" checked={promos} onChange={(v) => toggle("promos", v)} />
        <NotifRow label="Новости СЛЭЙ" desc="Новые товары и разделы" checked={news} onChange={(v) => toggle("news", v)} />
      </div>
    </div>
  );
}

function NotifRow({
  label,
  desc,
  checked,
  onChange
}: {
  label: string;
  desc: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <label className="flex cursor-pointer items-center justify-between gap-3 p-4">
      <span>
        <span className="block text-sm font-medium text-ink">{label}</span>
        <span className="block text-xs text-smoke-400">{desc}</span>
      </span>
      <button
        type="button"
        onClick={() => onChange(!checked)}
        aria-pressed={checked}
        className={cn("relative h-6 w-11 shrink-0 rounded-full transition-colors", checked ? "bg-lime-500" : "bg-smoke-200")}
      >
        <span className={cn("absolute top-0.5 h-5 w-5 rounded-full bg-white shadow-soft transition-transform", checked ? "translate-x-5" : "translate-x-0.5")} />
      </button>
    </label>
  );
}

function EmptyBlock({ text }: { text: string }) {
  return (
    <div className="flex flex-col items-center gap-2 rounded-xl2 border border-dashed border-smoke-200 py-12 text-center">
      <p className="text-sm text-smoke-500">{text}</p>
      <Link href="/catalog" className="mt-1 text-xs font-semibold text-lime-600">
        Перейти в каталог
      </Link>
    </div>
  );
}
