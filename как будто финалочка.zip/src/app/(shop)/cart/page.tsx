"use client";

import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import { ShoppingBag } from "lucide-react";
import { useCartStore, cartTotals } from "@/context/cart-store";
import CartLineItem from "@/components/cart-line-item";
import PromoInput from "@/components/promo-input";
import OrderSummary from "@/components/order-summary";

export default function CartPage() {
  const lines = useCartStore((s) => s.lines);
  const promoDiscountPercent = useCartStore((s) => s.promoDiscountPercent);
  const totals = cartTotals(lines, promoDiscountPercent);

  if (lines.length === 0) {
    return (
      <div className="mx-auto flex max-w-md flex-col items-center gap-3 px-4 py-24 text-center">
        <div className="flex h-16 w-16 items-center justify-center rounded-full bg-smoke-100">
          <ShoppingBag className="h-7 w-7 text-smoke-400" />
        </div>
        <h1 className="font-display text-lg font-bold">Корзина пуста</h1>
        <p className="text-sm text-smoke-500">Добавьте товары из каталога, чтобы оформить заказ</p>
        <Link href="/catalog" className="mt-2 rounded-full bg-lime-500 px-6 py-3 text-sm font-bold text-ink">
          В каталог
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-4 md:px-6">
      <h1 className="mb-2 font-display text-xl font-bold">Корзина</h1>

      <div className="divide-y divide-smoke-100">
        <AnimatePresence initial={false}>
          {lines.map((line) => (
            <CartLineItem key={line.product.id} line={line} />
          ))}
        </AnimatePresence>
      </div>

      <div className="mt-4 flex flex-col gap-4 pb-24 md:pb-0">
        <PromoInput />
        <OrderSummary {...totals} />
      </div>

      {/* Тот же приём, что и в ProductBuyBox/чекауте: на мобильном кнопка
          закреплена снизу над BottomNav, чтобы не нужно было долистывать
          длинную корзину до конца. На десктопе (md+) — обычный блок в потоке. */}
      <div
        className="fixed inset-x-0 bottom-[64px] z-30 border-t border-smoke-100 bg-white/95 px-4 py-3 shadow-[0_-6px_20px_rgba(0,0,0,0.06)] backdrop-blur-md
        pb-[calc(0.75rem+env(safe-area-inset-bottom))]
        md:static md:mt-4 md:inset-auto md:border-0 md:bg-transparent md:p-0 md:pb-0 md:shadow-none md:backdrop-blur-none"
      >
        <motion.div whileTap={{ scale: 0.98 }}>
          <Link
            href="/checkout"
            className="flex w-full items-center justify-center rounded-full bg-ink py-4 text-sm font-bold text-white"
          >
            Перейти к оформлению · {totals.total.toLocaleString("ru-RU")} ₽
          </Link>
        </motion.div>
      </div>
    </div>
  );
}
