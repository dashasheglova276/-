import type { Metadata } from "next";
import { getRecipes } from "@/lib/catalog";
import RecipeCard from "@/components/recipe-card";
import BackButton from "@/components/back-button";

export const metadata: Metadata = {
  title: "Рецепты — что приготовить"
};

export const revalidate = 0;

export default async function RecipesPage() {
  const recipes = await getRecipes();
  return (
    <div className="mx-auto max-w-6xl px-4 py-5 md:px-6">
      <BackButton className="mb-3" fallbackHref="/" />
      <h1 className="mb-1 font-display text-2xl font-extrabold text-ink">Что приготовить сегодня?</h1>
      <p className="mb-5 text-sm text-smoke-500">
        Выберите рецепт — добавим все ингредиенты в корзину одним нажатием.
      </p>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
        {recipes.map((recipe) => (
          <RecipeCard key={recipe.slug} recipe={recipe} />
        ))}
      </div>
    </div>
  );
}
