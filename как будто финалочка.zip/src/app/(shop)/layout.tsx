import TopNav from "@/components/top-nav";
import BottomNav from "@/components/bottom-nav";
import Footer from "@/components/footer";
import WelcomeModal from "@/components/welcome-modal";

export default function ShopLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col">
      <WelcomeModal />
      <TopNav />
      <main className="flex-1 pb-24 md:pb-8">
        {children}
        <Footer />
      </main>
      <BottomNav />
    </div>
  );
}
