"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { Product } from "@/data/products";
import { getLineTotal, getStepAmount } from "@/lib/utils";

export interface CartLine {
  product: Product;
  /** Штуки (saleType = "piece") или граммы (saleType = "weight"). */
  quantity: number;
}

interface CartState {
  lines: CartLine[];
  promoCode: string | null;
  promoDiscountPercent: number;
  addItem: (product: Product, qty?: number) => void;
  removeItem: (productId: string) => void;
  setQuantity: (productId: string, qty: number) => void;
  clear: () => void;
  setPromo: (code: string, discountPercent: number) => void;
  removePromo: () => void;
  quantityOf: (productId: string) => number;
}

export const useCartStore = create<CartState>()(
  persist(
    (set, get) => ({
      lines: [],
      promoCode: null,
      promoDiscountPercent: 0,
      addItem: (product, qty) => {
        const amount = qty ?? getStepAmount(product);
        const lines = get().lines;
        const existing = lines.find((l) => l.product.id === product.id);
        if (existing) {
          set({
            lines: lines.map((l) =>
              l.product.id === product.id ? { ...l, quantity: l.quantity + amount } : l
            )
          });
        } else {
          set({ lines: [...lines, { product, quantity: amount }] });
        }
      },
      removeItem: (productId) => {
        set({ lines: get().lines.filter((l) => l.product.id !== productId) });
      },
      setQuantity: (productId, qty) => {
        if (qty <= 0) {
          set({ lines: get().lines.filter((l) => l.product.id !== productId) });
          return;
        }
        set({
          lines: get().lines.map((l) =>
            l.product.id === productId ? { ...l, quantity: qty } : l
          )
        });
      },
      clear: () => set({ lines: [], promoCode: null, promoDiscountPercent: 0 }),
      setPromo: (code, discountPercent) => set({ promoCode: code.trim().toUpperCase(), promoDiscountPercent: discountPercent }),
      removePromo: () => set({ promoCode: null, promoDiscountPercent: 0 }),
      quantityOf: (productId) => {
        const line = get().lines.find((l) => l.product.id === productId);
        return line ? line.quantity : 0;
      }
    }),
    {
  name: "slay-cart",
  skipHydration: true,
}
  )
);

export function cartTotals(lines: CartLine[], promoDiscountPercent: number) {
  const subtotal = lines.reduce((sum, l) => sum + getLineTotal(l.product.price, l.quantity, l.product), 0);
  const productDiscount = lines.reduce(
    (sum, l) =>
      sum + (l.product.oldPrice ? getLineTotal(l.product.oldPrice - l.product.price, l.quantity, l.product) : 0),
    0
  );
  const promoDiscount = Math.round((subtotal * promoDiscountPercent) / 100);
  const deliveryFee = subtotal === 0 || subtotal >= 1500 ? 0 : 199;
  const total = Math.max(subtotal - promoDiscount, 0) + deliveryFee;
  return { subtotal, productDiscount, promoDiscount, deliveryFee, total };
}
