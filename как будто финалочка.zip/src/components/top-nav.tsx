"use client";

import Link from "next/link";
import { Search, User, ShoppingCart, Heart } from "lucide-react";
import { useCartStore } from "@/context/cart-store";
import { useFavoritesStore } from "@/context/favorites-store";

export default function TopNav() {
  // Считаем количество позиций в корзине, а не сумму quantity: для весовых
  // товаров quantity хранится в граммах (например, 200 г), и суммирование
  // "сырых" значений превращало бейдж в абсурдные числа вроде 200.
  const itemsCount = useCartStore((s) => s.lines.length);
  const favoritesCount = useFavoritesStore((s) => s.ids.length);

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-white/90 backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3 md:px-6">
        <Link href="/" className="flex items-center gap-1.5 shrink-0">
          <span className="font-display text-xl font-extrabold tracking-tight text-ink">СЛЭЙ</span>
          <span className="rounded-full bg-lime-500 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-ink">
            15 мин
          </span>
        </Link>

        <div className="flex-1" />

        {/* Раньше здесь стояло собственное поле поиска — дублировало
            крупную SearchBar на Главной/Каталоге. Теперь это просто
            компактная иконка-вход на страницу поиска, без своей логики. */}
        <Link
          href="/search"
          aria-label="Поиск"
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-smoke-100 transition-colors hover:bg-smoke-200"
        >
          <Search size={18} />
        </Link>

        {/* Раньше /favorites не было ссылки нигде в интерфейсе — страница была недостижима. */}
        <Link
          href="/favorites"
          aria-label="Избранное"
          className="relative flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-smoke-100 transition-colors hover:bg-smoke-200"
        >
          <Heart size={18} className={favoritesCount > 0 ? "fill-flash-500 text-flash-500" : ""} />
        </Link>

        <Link
          href="/profile"
          aria-label="Профиль"
          className="hidden h-10 w-10 shrink-0 items-center justify-center rounded-full bg-smoke-100 transition-colors hover:bg-smoke-200 sm:flex"
        >
          <User size={18} />
        </Link>

        <Link
          href="/cart"
          aria-label="Корзина"
          className="relative hidden h-10 w-10 shrink-0 items-center justify-center rounded-full bg-ink text-white transition-colors hover:bg-smoke-800 sm:flex"
        >
          <ShoppingCart size={18} />
          {itemsCount > 0 && (
            <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-flash-500 px-1 text-[10px] font-bold text-white">
              {itemsCount}
            </span>
          )}
        </Link>
      </div>
    </header>
  );
}
