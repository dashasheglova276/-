import type { Product } from "@/data/products";
import ProductCard from "@/components/product-card";

export default function ProductGrid({ products }: { products: Product[] }) {
  if (products.length === 0) {
    return (
      <div className="flex flex-col items-center gap-2 py-16 text-center">
        <span className="text-3xl">🔍</span>
        <p className="text-sm font-medium text-smoke-500">Ничего не нашлось</p>
        <p className="text-xs text-smoke-400">Попробуйте изменить запрос или фильтры</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
      {products.map((product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  );
}
