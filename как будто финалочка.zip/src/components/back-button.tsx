"use client";

import { useRouter } from "next/navigation";
import { ChevronLeft } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * Минималистичная кнопка "Назад" — используется на страницах товара, каталога,
 * категории, рецепта, профиля и в админке. По умолчанию идёт по истории
 * браузера (router.back()); если истории нет (например, страница открыта по
 * прямой ссылке), переходит на fallbackHref.
 */
export default function BackButton({
  fallbackHref = "/",
  label = "Назад",
  className
}: {
  fallbackHref?: string;
  label?: string;
  className?: string;
}) {
  const router = useRouter();

  function handleClick() {
    // history.length почти всегда > 1 (в него попадает вся история вкладки,
    // а не только переходы внутри сайта), поэтому раньше эта проверка почти
    // всегда уводила в router.back() — включая случаи, когда предыдущая
    // запись истории вела на страницу с серверным редиректом обратно на
    // текущую (кнопка "зависала", бесконечно возвращая на то же место).
    // document.referrer надёжнее: смотрим, что реально открывалось до этого.
    const referrer = typeof document !== "undefined" ? document.referrer : "";
    const sameOrigin = referrer && typeof window !== "undefined" && referrer.startsWith(window.location.origin);
    const referrerIsCurrentPage =
      sameOrigin && typeof window !== "undefined" && referrer === window.location.href;

    if (sameOrigin && !referrerIsCurrentPage && window.history.length > 1) {
      router.back();
    } else {
      router.push(fallbackHref);
    }
  }

  return (
    <button
      type="button"
      onClick={handleClick}
      aria-label={label}
      className={cn(
        "flex items-center gap-1 rounded-full border border-line bg-white/80 px-3 py-1.5 text-xs font-semibold text-smoke-600 shadow-subtle backdrop-blur-md transition-colors hover:bg-white",
        className
      )}
    >
      <ChevronLeft size={15} />
      {label}
    </button>
  );
}
