"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { Heart, Plus, Check } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import type { Product } from "@/data/products";
import { useCartStore } from "@/context/cart-store";
import { useFavoritesStore } from "@/context/favorites-store";
import { useToastStore } from "@/context/toast-store";
import { formatPrice, formatWeight, formatCartAmount, getStepAmount, cn } from "@/lib/utils";
import QuantityStepper from "@/components/quantity-stepper";

export default function ProductCard({
  product,
  className
}: {
  product: Product;
  className?: string;
}) {
  const quantity = useCartStore((s) => s.quantityOf(product.id));
  const addItem = useCartStore((s) => s.addItem);
  const setQuantity = useCartStore((s) => s.setQuantity);
  const isFavorite = useFavoritesStore((s) => s.isFavorite(product.id));
  const toggleFavorite = useFavoritesStore((s) => s.toggle);
  const showToast = useToastStore((s) => s.show);
  const inStock = product.inStock !== false;
  const isWeighted = product.saleType === "weight";
  const step = getStepAmount(product);
  const [justAdded, setJustAdded] = useState(false);

  function handleAdd() {
    addItem(product);
    setJustAdded(true);
    showToast(`«${product.name}» в корзине`, "success");
    setTimeout(() => setJustAdded(false), 900);
  }

  return (
    <motion.div
      whileHover={{ y: -3 }}
      transition={{ type: "spring", stiffness: 300, damping: 22 }}
      className={cn(
        "group relative flex flex-col overflow-hidden rounded-xl2 border border-line bg-white shadow-subtle transition-all duration-200 hover:-translate-y-0.5 hover:shadow-card",
        className
      )}
    >
      {/* Фото товара — увеличенная высота (4:5 вместо квадрата) для более
          заметного визуального акцента на изображении, как в мобильной Лавке. */}
      <Link href={`/product/${product.id}`} className="relative block aspect-[4/5] overflow-hidden bg-smoke-50">
        {(product.discountPercent > 0 || product.isNew) && (
          <div className="absolute left-2 top-2 z-10 flex flex-col items-start gap-1">
            {product.discountPercent > 0 && (
              <span className="rounded-full bg-flash-500 px-2.5 py-1 text-[11px] font-extrabold text-white shadow-glowFlash">
                −{product.discountPercent}%
              </span>
            )}
            {product.isNew && (
              <span className="rounded-full bg-ink px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide text-white shadow-subtle">
                Новинка
              </span>
            )}
          </div>
        )}
        <Image
          src={product.image}
          alt={product.name}
          fill
          sizes="(max-width: 768px) 45vw, 220px"
          className={cn(
            "object-cover transition-transform duration-500 group-hover:scale-105",
            !inStock && "grayscale"
          )}
        />
        {!inStock && (
          <div className="absolute inset-0 flex items-center justify-center bg-white/60">
            <span className="rounded-full bg-ink/90 px-3 py-1 text-[11px] font-bold text-white">
              Нет в наличии
            </span>
          </div>
        )}
        <button
          aria-label={isFavorite ? "Убрать из избранного" : "Добавить в избранное"}
          onClick={(e) => {
            e.preventDefault();
            toggleFavorite(product.id);
          }}
          className="absolute right-2 top-2 z-10 flex h-8 w-8 items-center justify-center rounded-full bg-white/80 shadow-soft backdrop-blur-md transition-transform active:scale-90"
        >
          <Heart
            size={16}
            className={cn(
              "transition-colors",
              isFavorite ? "fill-flash-500 text-flash-500" : "text-smoke-400"
            )}
          />
        </button>
      </Link>

      {/* Быстрое добавление/степпер — "плавающая" кнопка, наполовину лежащая
          на фото, наполовину на карточке снизу, как в мобильных приложениях
          доставки. Логика addItem/setQuantity не меняется, только позиция. */}
      {inStock && (
        <div className="relative z-10 -mt-4 flex justify-end pr-2.5">
          {quantity === 0 ? (
            <motion.button
              aria-label="Добавить в корзину"
              onClick={handleAdd}
              whileTap={{ scale: 0.88 }}
              className="relative flex h-9 w-9 shrink-0 items-center justify-center overflow-hidden rounded-full bg-lime-500 text-ink shadow-glowLime"
            >
              <AnimatePresence mode="wait" initial={false}>
                {justAdded ? (
                  <motion.span
                    key="check"
                    initial={{ scale: 0.4, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.4, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <Check size={18} />
                  </motion.span>
                ) : (
                  <motion.span
                    key="plus"
                    initial={{ scale: 0.4, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.4, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <Plus size={18} />
                  </motion.span>
                )}
              </AnimatePresence>
            </motion.button>
          ) : (
            <QuantityStepper
              size="sm"
              quantity={quantity}
              label={isWeighted ? formatCartAmount(quantity, product) : undefined}
              onIncrement={() => addItem(product, step)}
              onDecrement={() => setQuantity(product.id, quantity - step)}
              className="shadow-lift"
            />
          )}
        </div>
      )}

      <div className={cn("flex flex-1 flex-col gap-1 px-3 pb-3", inStock ? "pt-1" : "pt-3")}>
        <Link href={`/product/${product.id}`} className="line-clamp-2 min-h-[2.5rem] text-sm font-medium text-ink">
          {product.name}
        </Link>
        <span className="text-xs text-smoke-400">{formatWeight(product.weight, product.unit)}</span>

        <div className="mt-1 flex items-center justify-between gap-2">
          <div className="flex flex-col">
            <span className="font-display text-lg font-bold text-ink">
              {formatPrice(product.price)}
              {isWeighted && <span className="ml-0.5 text-[11px] font-medium text-smoke-400">/кг</span>}
            </span>
            {product.oldPrice && (
              <span className="text-xs text-smoke-400 line-through">{formatPrice(product.oldPrice)}</span>
            )}
          </div>

          {!inStock && (
            <span className="shrink-0 rounded-full bg-smoke-100 px-3 py-1.5 text-[11px] font-semibold text-smoke-400">
              Нет в наличии
            </span>
          )}
        </div>
      </div>
    </motion.div>
  );
}
