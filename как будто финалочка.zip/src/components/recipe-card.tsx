import Image from "next/image";
import Link from "next/link";
import { Clock, Gauge } from "lucide-react";
import type { Recipe } from "@/data/recipes";

/**
 * Карточка рецепта, где фото — главный элемент (занимает верхние ~70%
 * карточки), а не просто иллюстрация к описанию. Время и сложность —
 * компактными плашками прямо на фото, название — одной строкой под фото.
 */
export default function RecipeCard({ recipe }: { recipe: Recipe }) {
  return (
    <Link
      href={`/recipes/${recipe.slug}`}
      className="group flex flex-col overflow-hidden rounded-2xl border border-line bg-white transition-all duration-200 hover:-translate-y-0.5 hover:shadow-card"
    >
      <div className="relative aspect-[4/3] w-full overflow-hidden bg-smoke-50">
        <Image
          src={recipe.image}
          alt={recipe.title}
          fill
          sizes="320px"
          className="object-cover transition-transform duration-300 group-hover:scale-105"
        />
        <div className="absolute left-2 top-2 flex items-center gap-1 rounded-full bg-white/90 px-2 py-1 text-[11px] font-semibold text-ink backdrop-blur-sm">
          <Clock size={12} />
          {recipe.cookTimeMinutes} мин
        </div>
        <div className="absolute right-2 top-2 flex items-center gap-1 rounded-full bg-white/90 px-2 py-1 text-[11px] font-semibold text-ink backdrop-blur-sm">
          <Gauge size={12} />
          {recipe.difficulty}
        </div>
      </div>

      <div className="flex flex-1 flex-col justify-between gap-1 p-3">
        <p className="line-clamp-2 text-[13px] font-semibold leading-snug text-ink">{recipe.title}</p>
        <p className="text-[11px] text-smoke-400">{recipe.ingredients.length} ингредиентов</p>
      </div>
    </Link>
  );
}
