"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, LayoutGrid, ChefHat, ShoppingCart, User } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { useCartStore } from "@/context/cart-store";

const items = [
  { href: "/", label: "Главная", icon: Home, match: ["/"] },
  { href: "/catalog", label: "Каталог", icon: LayoutGrid, match: ["/catalog", "/category"] },
  { href: "/recipes", label: "Рецепты", icon: ChefHat, match: ["/recipes"] },
  { href: "/cart", label: "Корзина", icon: ShoppingCart, match: ["/cart", "/checkout"] },
  { href: "/profile", label: "Профиль", icon: User, match: ["/profile", "/favorites"] }
];

export default function BottomNav() {
  const pathname = usePathname();
  // Считаем количество позиций в корзине, а не сумму quantity: для весовых
  // товаров quantity хранится в граммах (например, 200 г), и суммирование
  // "сырых" значений превращало бейдж в абсурдные числа вроде 200.
  const itemsCount = useCartStore((s) => s.lines.length);

  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-40 border-t border-smoke-100 bg-white/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-md md:hidden"
    >
      <div className="grid grid-cols-5">
        {items.map(({ href, label, icon: Icon, match }) => {
          const isActive =
            pathname === href || match.some((prefix) => prefix !== "/" && pathname.startsWith(prefix));
          return (
            <Link
              key={href}
              href={href}
              className="relative flex flex-col items-center gap-0.5 py-2.5 text-[10px]"
            >
              {isActive && (
                <motion.span
                  layoutId="bottom-nav-active-pill"
                  className="absolute top-1 h-8 w-12 rounded-full bg-lime-50"
                  transition={{ type: "spring", stiffness: 420, damping: 32 }}
                />
              )}
              <div className="relative">
                <Icon
                  size={20}
                  className={cn("relative transition-colors duration-200", isActive ? "text-lime-600" : "text-smoke-400")}
                  strokeWidth={isActive ? 2.4 : 2}
                />
                {href === "/cart" && itemsCount > 0 && (
                  <span className="absolute -right-2 -top-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-flash-500 px-1 text-[9px] font-bold text-white">
                    {itemsCount}
                  </span>
                )}
              </div>
              <span className={cn("relative font-medium transition-colors duration-200", isActive ? "text-ink" : "text-smoke-400")}>
                {label}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
