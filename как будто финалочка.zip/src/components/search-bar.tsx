"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { Search, X, ArrowRight } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import type { Product } from "@/data/products";
import ProductGrid from "@/components/product-grid";

// Слова для анимированного placeholder, когда пользователь ещё ничего не
// ввёл — печатаются и стираются по очереди, как в мобильных приложениях
// доставки ("Ищу..." → "Молоко" → "Огурцы" → ...).
const SUGGESTIONS = ["Ищу...", "Молоко", "Огурцы", "Кофе", "Хлеб"];

const INLINE_RESULTS_LIMIT = 6;

function useTypewriterPlaceholder(active: boolean) {
  const [text, setText] = useState("");
  const wordIndex = useRef(0);
  const charIndex = useRef(0);
  const deleting = useRef(false);

  useEffect(() => {
    if (!active) return;

    const tick = () => {
      const word = SUGGESTIONS[wordIndex.current];

      if (!deleting.current) {
        charIndex.current += 1;
        setText(word.slice(0, charIndex.current));
        if (charIndex.current === word.length) {
          deleting.current = true;
          return 1100; // пауза перед стиранием
        }
        return 65;
      }

      charIndex.current -= 1;
      setText(word.slice(0, charIndex.current));
      if (charIndex.current === 0) {
        deleting.current = false;
        wordIndex.current = (wordIndex.current + 1) % SUGGESTIONS.length;
        return 350;
      }
      return 35;
    };

    let timeout: ReturnType<typeof setTimeout>;
    // Раньше цикл крутился ~15-20 раз в секунду даже во вкладке в фоне —
    // лишняя нагрузка на CPU, когда пользователь ушёл в другую вкладку.
    // Пауза через Page Visibility API — без новых зависимостей.
    const loop = () => {
      if (document.hidden) {
        timeout = setTimeout(loop, 300);
        return;
      }
      const delay = tick();
      timeout = setTimeout(loop, delay);
    };
    timeout = setTimeout(loop, 65);

    return () => clearTimeout(timeout);
  }, [active]);

  return text;
}

export default function SearchBar() {
  const [query, setQuery] = useState("");
  const [focused, setFocused] = useState(false);
  const [results, setResults] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const showTypewriter = !query && !focused;
  const placeholderText = useTypewriterPlaceholder(showTypewriter);

  // Та же логика debounce, что уже проверена на /search — здесь просто
  // повторно используем существующий API, ничего в нём не меняя.
  useEffect(() => {
    const trimmed = query.trim();
    if (!trimmed) {
      setResults([]);
      return;
    }
    setLoading(true);
    const timeout = setTimeout(() => {
      fetch(`/api/products?query=${encodeURIComponent(trimmed)}`)
        .then((res) => res.json())
        .then((data) => setResults(data.products ?? []))
        .finally(() => setLoading(false));
    }, 300);
    return () => clearTimeout(timeout);
  }, [query]);

  const trimmedQuery = query.trim();
  const isOpen = trimmedQuery.length > 0;

  return (
    <div className="relative">
      <div
        className={`relative flex items-center rounded-full border border-line bg-white shadow-soft transition-shadow duration-200 ${
          focused ? "ring-2 ring-lime-500/30" : ""
        }`}
      >
        <Search size={19} className="pointer-events-none absolute left-4 text-smoke-400" />
        <input
          ref={inputRef}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          type="search"
          inputMode="search"
          enterKeyHint="search"
          aria-label="Поиск товаров"
          className="w-full bg-transparent py-4 pl-11 pr-11 text-[15px] outline-none placeholder:text-smoke-400"
        />
        {/* Анимированный "печатающийся" placeholder поверх пустого инпута —
            настоящий атрибут placeholder так не умеет, поэтому рисуем текст
            отдельным слоем и прячем его при вводе/фокусе. */}
        {showTypewriter && (
          <span className="pointer-events-none absolute left-11 text-[15px] text-smoke-400">
            {placeholderText}
            <span className="animate-pulse">|</span>
          </span>
        )}
        <AnimatePresence>
          {query && (
            <motion.button
              key="clear"
              initial={{ opacity: 0, scale: 0.7 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.7 }}
              onClick={() => {
                setQuery("");
                inputRef.current?.focus();
              }}
              aria-label="Очистить поиск"
              className="absolute right-3.5 flex h-6 w-6 items-center justify-center rounded-full bg-smoke-100 text-smoke-500"
            >
              <X size={14} />
            </motion.button>
          )}
        </AnimatePresence>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2 }}
            className="mt-3"
          >
            <p className="mb-3 text-xs text-smoke-400">
              {loading ? "Ищем…" : `${results.length} результатов по запросу «${trimmedQuery}»`}
            </p>

            <ProductGrid products={results.slice(0, INLINE_RESULTS_LIMIT)} />

            {!loading && results.length > INLINE_RESULTS_LIMIT && (
              <Link
                href={`/search?q=${encodeURIComponent(trimmedQuery)}`}
                className="mt-4 flex items-center justify-center gap-1.5 rounded-full border border-smoke-200 py-3 text-sm font-semibold text-smoke-600 transition-colors hover:bg-smoke-50"
              >
                Показать все {results.length} результатов
                <ArrowRight size={15} />
              </Link>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
