import type { Product } from "@/data/products";
import ProductCard from "@/components/product-card";

export default function ProductRail({ products }: { products: Product[] }) {
  return (
    <div className="no-scrollbar -mx-4 flex gap-3 overflow-x-auto px-4 md:-mx-6 md:px-6">
      {products.map((product) => (
        <ProductCard key={product.id} product={product} className="w-[42vw] shrink-0 sm:w-48 md:w-52" />
      ))}
    </div>
  );
}
