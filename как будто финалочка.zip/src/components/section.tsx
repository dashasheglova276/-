import Link from "next/link";
import { ChevronRight } from "lucide-react";

export default function Section({
  title,
  subtitle,
  href,
  children
}: {
  title: string;
  subtitle?: string;
  href?: string;
  children: React.ReactNode;
}) {
  return (
    <section className="py-4">
      <div className="mb-3 flex items-end justify-between">
        <div>
          <h2 className="font-display text-lg font-extrabold tracking-tight text-ink sm:text-xl">{title}</h2>
          {subtitle && <p className="mt-0.5 text-xs text-smoke-400">{subtitle}</p>}
        </div>
        {href && (
          <Link
            href={href}
            className="flex shrink-0 items-center gap-0.5 rounded-full bg-smoke-50 px-3 py-1.5 text-xs font-semibold text-smoke-600 transition-colors hover:bg-lime-100 hover:text-lime-700"
          >
            Все
            <ChevronRight size={14} />
          </Link>
        )}
      </div>
      {children}
    </section>
  );
}
