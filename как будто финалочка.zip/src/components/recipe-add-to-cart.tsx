"use client";

import { useState } from "react";
import { Check, ShoppingCart } from "lucide-react";
import { useCartStore } from "@/context/cart-store";
import { useToastStore } from "@/context/toast-store";
import type { Recipe } from "@/data/recipes";
import type { Product } from "@/data/products";

/**
 * Одно из основных сценариев покупки по ТЗ: открыв рецепт, пользователь
 * может добавить все ингредиенты в корзину одной кнопкой. Товары
 * запрашиваются по id так же, как в блоке "Повторить заказ".
 */
export default function RecipeAddToCart({ recipe }: { recipe: Recipe }) {
  const addItem = useCartStore((s) => s.addItem);
  const showToast = useToastStore((s) => s.show);
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);

  async function addAll() {
    setLoading(true);
    try {
      const ids = recipe.ingredients.map((i) => i.productId).join(",");
      const res = await fetch(`/api/products?ids=${ids}`);
      const data = await res.json();
      const products: Product[] = data.products ?? [];
      products.forEach((product) => addItem(product));
      setDone(true);
      showToast(`Ингредиенты для «${recipe.title}» в корзине`, "success");
      setTimeout(() => setDone(false), 1600);
    } catch {
      showToast("Не удалось добавить ингредиенты, попробуйте ещё раз", "error");
    } finally {
      setLoading(false);
    }
  }

  return (
    <button
      onClick={addAll}
      disabled={loading}
      className="flex w-full items-center justify-center gap-2 rounded-full bg-lime-500 px-6 py-3.5 text-sm font-bold text-ink shadow-glowLime transition-transform active:scale-95 disabled:opacity-60 sm:w-auto"
    >
      {done ? <Check size={17} /> : <ShoppingCart size={17} />}
      {loading ? "Добавляем..." : done ? "Добавлено" : "Добавить все ингредиенты в корзину"}
    </button>
  );
}
