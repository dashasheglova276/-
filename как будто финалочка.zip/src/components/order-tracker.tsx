"use client";

import { motion } from "framer-motion";
import { ClipboardList, ShoppingCart, PackageCheck, Bike, CheckCircle2, Check } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { ORDER_STATUS_FLOW, type OrderStatus } from "@/types";
import { cn } from "@/lib/utils";

// Подписи и иконки специально под трекер — отличаются от ORDER_STATUS_LABELS
// (тот используется для компактного StatusBadge в других местах интерфейса
// и его лейблы короче/нейтральнее). Порядок совпадает с ORDER_STATUS_FLOW.
const STEPS: { status: OrderStatus; icon: LucideIcon; label: string }[] = [
  { status: "new", icon: ClipboardList, label: "Ожидает подтверждения" },
  { status: "accepted", icon: ShoppingCart, label: "Подтверждён, собираем" },
  { status: "picked_up", icon: PackageCheck, label: "Собрали заказ" },
  { status: "in_transit", icon: Bike, label: "Курьер в пути" },
  { status: "delivered", icon: CheckCircle2, label: "Доставлено" }
];

export default function OrderTracker({ status }: { status: OrderStatus }) {
  const currentIndex = ORDER_STATUS_FLOW.indexOf(status);

  return (
    <div className="flex flex-col rounded-xl2 border border-smoke-100 p-4">
      {STEPS.map((step, i) => {
        const state = i < currentIndex ? "done" : i === currentIndex ? "current" : "upcoming";
        const isLast = i === STEPS.length - 1;

        return (
          <motion.div
            key={step.status}
            initial={{ opacity: 0, x: -8 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.07, duration: 0.25, ease: "easeOut" }}
            className="flex gap-3"
          >
            <div className="flex flex-col items-center">
              <motion.div
                animate={state === "current" ? { scale: [1, 1.08, 1] } : { scale: 1 }}
                transition={
                  state === "current"
                    ? { duration: 1.8, repeat: Infinity, ease: "easeInOut" }
                    : { duration: 0.2 }
                }
                className={cn(
                  "relative flex h-10 w-10 shrink-0 items-center justify-center rounded-full",
                  state === "upcoming" ? "bg-smoke-100 text-smoke-300" : "bg-lime-500 text-ink"
                )}
              >
                <step.icon size={18} />
                {state === "done" && (
                  <span className="absolute -bottom-0.5 -right-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-white ring-1 ring-lime-500">
                    <Check size={9} className="text-lime-600" />
                  </span>
                )}
              </motion.div>
              {!isLast && (
                <div className="relative w-0.5 flex-1 min-h-[26px] overflow-hidden rounded-full bg-smoke-100">
                  <motion.div
                    initial={false}
                    animate={{ height: i < currentIndex ? "100%" : "0%" }}
                    transition={{ duration: 0.35, delay: i * 0.07 + 0.1, ease: "easeOut" }}
                    className="absolute inset-x-0 top-0 bg-lime-500"
                  />
                </div>
              )}
            </div>

            <div className={cn("pb-6", isLast && "pb-0")}>
              <p className={cn("text-sm font-semibold", state === "upcoming" ? "text-smoke-300" : "text-ink")}>
                {step.label}
              </p>
              {state === "current" && (
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.2 }}
                  className="mt-0.5 text-xs font-medium text-lime-600"
                >
                  Сейчас
                </motion.p>
              )}
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}
