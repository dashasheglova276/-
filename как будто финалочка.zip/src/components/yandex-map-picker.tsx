"use client";

import { useEffect, useRef, useState } from "react";
import { MapPin, AlertCircle } from "lucide-react";

declare global {
  interface Window {
    ymaps?: any;
  }
}

const DEFAULT_CENTER: [number, number] = [44.9521, 34.1024];

/**
 * Из полного ответа геокодера оставляет только "Город, улица, дом" —
 * без страны/региона/индекса, как просили в задаче (пункт 8).
 */
function extractShortAddress(geoObject: any, fallbackText: string): string {
  const components: { kind: string; name: string }[] =
    geoObject?.metaDataProperty?.GeocoderMetaData?.Address?.Components ?? [];
  const byKind = (kind: string) => components.find((c) => c.kind === kind)?.name;

  const locality = byKind("locality") || byKind("area") || byKind("province");
  const street = byKind("street");
  const house = byKind("house");

  const parts = [locality, [street, house].filter(Boolean).join(", ")].filter(Boolean);
  return parts.length > 0 ? parts.join(", ") : fallbackText;
}

export default function YandexMapPicker({
  onSelect,
  value,
  className
}: {
  onSelect: (data: { address: string; lat: number; lng: number }) => void;
  /** Позволяет родителю (например, клику по сохранённому адресу) задать значение поля извне. */
  value?: string;
  className?: string;
}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const mapRef = useRef<any>(null);

  const [ready, setReady] = useState(false);
  const [query, setQuery] = useState(value ?? "");
  const [scriptError, setScriptError] = useState(false);
  const [geocodeError, setGeocodeError] = useState(false);

  const mapKey = process.env.NEXT_PUBLIC_YANDEX_MAPS_API_KEY;
  const geocoderKey = process.env.NEXT_PUBLIC_YANDEX_GEOCODER_API_KEY;
  const suggestKey = process.env.NEXT_PUBLIC_YANDEX_SUGGEST_API_KEY;

  // Синхронизируем с внешним значением (например, выбор сохранённого адреса в чек-ауте),
  // но не перетираем то, что пользователь уже печатает сам.
  //
  // Раньше здесь обновлялось только текстовое поле (query), а карта и метка
  // оставались на месте, потому что для сохранённого адреса нет готовых
  // координат. Теперь при внешней смене адреса дополнительно геокодируем
  // текст и двигаем карту к найденной точке — так же, как это уже делает
  // searchTypedAddress() для адреса, введённого руками.
  useEffect(() => {
    if (value !== undefined && value !== query && document.activeElement !== inputRef.current) {
      setQuery(value);

      const ymaps = window.ymaps;
      const map = mapRef.current;
      const trimmed = value.trim();
      if (ymaps && map && trimmed) {
        ymaps
          .geocode(trimmed)
          .then((res: any) => {
            const first = res.geoObjects.get(0);
            if (!first) return;
            const coords = first.geometry.getCoordinates() as [number, number];
            map.setCenter(coords, 17);
            getAddress(coords);
          })
          .catch(() => setGeocodeError(true));
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);

  useEffect(() => {
    if (!mapKey) return;

    if (window.ymaps) {
      window.ymaps.ready(() => setReady(true));
      return;
    }

    const script = document.createElement("script");

    // suggest_apikey обязателен, иначе SuggestView молча не выдаёт подсказки
    // (это и была причина бага "нет подсказок").
    const suggestParam = suggestKey ? `&suggest_apikey=${suggestKey}` : "";
    script.src = `https://api-maps.yandex.ru/2.1/?apikey=${mapKey}${suggestParam}&lang=ru_RU`;

    script.async = true;

    script.onload = () => {
      window.ymaps.ready(() => setReady(true));
    };

    script.onerror = () => {
      setScriptError(true);
    };

    document.head.appendChild(script);
  }, [mapKey, suggestKey]);

  async function getAddress(coords: [number, number]) {
    if (!geocoderKey) {
      setGeocodeError(true);
      return;
    }
    try {
      const url =
        `https://geocode-maps.yandex.ru/1.x/` +
        `?apikey=${geocoderKey}` +
        `&geocode=${coords[1]},${coords[0]}` +
        `&format=json`;

      const response = await fetch(url);
      const data = await response.json();

      const geoObject = data?.response?.GeoObjectCollection?.featureMember?.[0]?.GeoObject;
      if (!geoObject) {
        setGeocodeError(true);
        return;
      }

      const fullText = geoObject?.metaDataProperty?.GeocoderMetaData?.text ?? `${coords[0]}, ${coords[1]}`;
      const address = extractShortAddress(geoObject, fullText);

      setGeocodeError(false);
      setQuery(address);
      onSelect({ address, lat: coords[0], lng: coords[1] });
    } catch (error) {
      console.error("Ошибка Геокодера:", error);
      setGeocodeError(true);
    }
  }

  /** Ищет введённый адрес напрямую — резервный путь на случай, если подсказка не была выбрана мышью/тапом. */
  function searchTypedAddress() {
    const ymaps = window.ymaps;
    const map = mapRef.current;
    if (!ymaps || !map || !query.trim()) return;
    ymaps
      .geocode(query.trim())
      .then((res: any) => {
        const first = res.geoObjects.get(0);
        if (!first) {
          setGeocodeError(true);
          return;
        }
        const coords = first.geometry.getCoordinates() as [number, number];
        map.setCenter(coords, 17);
        getAddress(coords);
      })
      .catch(() => setGeocodeError(true));
  }

  useEffect(() => {
    if (!ready || !containerRef.current || mapRef.current) return;

    const ymaps = window.ymaps;

    const map = new ymaps.Map(containerRef.current, {
      center: DEFAULT_CENTER,
      zoom: 16,
      controls: ["zoomControl", "geolocationControl"]
    });

    mapRef.current = map;

    map.events.add("actionend", () => {
      const center = map.getCenter() as [number, number];
      getAddress(center);
    });

    if (inputRef.current) {
      const suggest = new ymaps.SuggestView(inputRef.current, {
        results: 5
      });

      suggest.events.add("select", (e: any) => {
        const value = e.get("item").value;

        ymaps.geocode(value).then((res: any) => {
          const first = res.geoObjects.get(0);
          if (!first) return;

          const coords = first.geometry.getCoordinates() as [number, number];

          map.setCenter(coords, 17);
          getAddress(coords);
        });
      });
    }

    getAddress(DEFAULT_CENTER);

    ymaps.geolocation
      .get({ provider: "browser", mapStateAutoApply: true })
      .then((result: any) => {
        const coords = result.geoObjects.position as [number, number];
        map.setCenter(coords, 17);
        getAddress(coords);
      })
      .catch(() => {});
  }, [ready]);

  if (!mapKey) {
    return (
      <div className="flex items-center gap-2 rounded-xl2 border border-smoke-200 bg-smoke-50 p-4 text-sm text-smoke-500">
        <AlertCircle size={16} className="shrink-0 text-smoke-400" />
        Карта временно недоступна: нет ключа Яндекс.Карт
      </div>
    );
  }

  if (scriptError) {
    return (
      <div className="flex items-center gap-2 rounded-xl2 border border-smoke-200 bg-smoke-50 p-4 text-sm text-smoke-500">
        <AlertCircle size={16} className="shrink-0 text-smoke-400" />
        Не удалось загрузить Яндекс.Карты. Проверьте соединение и обновите страницу.
      </div>
    );
  }

  return (
    <div className={className}>
      <div className="relative mb-2">
        <MapPin size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-smoke-400" />
        <input
          ref={inputRef}
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setGeocodeError(false);
          }}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              searchTypedAddress();
            }
          }}
          onBlur={searchTypedAddress}
          placeholder="Город, улица, дом"
          required
          className="w-full rounded-xl2 border border-smoke-200 bg-white py-3 pl-10 pr-3 text-sm outline-none ring-lime-500/60 transition-shadow focus:ring-2"
        />
      </div>

      {/* Рамка + тень — та же карточная стилистика, что у остальных блоков SLAY,
          чтобы карта не выглядела как случайно вставленный сторонний виджет. */}
      <div className="relative overflow-hidden rounded-xl2 border border-smoke-100 shadow-subtle">
        <div ref={containerRef} className="h-56 w-full bg-smoke-50 sm:h-64" />

        <div className="pointer-events-none absolute left-1/2 top-1/2 z-10 -translate-x-1/2 -translate-y-full">
          <MapPin size={44} className="text-flash-500 drop-shadow-lg" fill="currentColor" />
        </div>
      </div>

      {geocodeError ? (
        <p className="mt-2 flex items-center gap-1.5 text-xs text-flash-600">
          <AlertCircle size={13} />
          Не удалось определить адрес. Попробуйте передвинуть карту или ввести адрес точнее.
        </p>
      ) : (
        <p className="mt-2 text-xs text-smoke-400">Передвиньте карту — адрес определится автоматически.</p>
      )}
    </div>
  );
}